package io.jrest;

public enum HttpMethod {
	GET,
	POST,
	DELETE,
	HEAD,
	OPTIONS,
	PATCH,
	PUT,
	TRACE;
}
